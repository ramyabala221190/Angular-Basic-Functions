import {Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Observable} from 'rxjs/Rx';
import {Comment} from '../components/appComponent';
import {countries} from '../components/CountriesList';

@Injectable()

export class UserService
{

base_url:string='https://jsonplaceholder.typicode.com/';
swap_url:string='https://swapi.co/api/';

constructor(private http:Http) {}

handleError(error:any)
{
console.log(error);
return Observable.throw(error.json().error||'Server error');

}

createComment(postid:number,ids:number,names:string,emails:string,comm:string)
{

var content:Comment[]=[
{
postId:postid,
id:ids,
name:names,
email:emails,
body:comm
}
]    
return this.http.post(this.base_url+'comments',content)
.map(success=>success.status)
.catch(this.handleError);

}

deleteComment(id:number)
{
    console.log(id);
return this.http.delete(this.base_url+'comments/'+id)
.map(success=>success.status)
.catch(this.handleError);
}

editComment(postid:number,names:string,emails:string,comm:string)
{
    console.log(postid);
    var editedContent:any[]=[
        /**Its of type any[] becuase we can use Comment only if we are using all its properties */
        {
name:names,
email:emails,
body:comm
        }
    ]
return this.http.put(this.base_url+'comments/'+postid,editedContent)
.map(success=>success.status)
.catch(this.handleError);

}

/*getUserDetails()
{


}*/

getAllPersonsDetails()
{
return this.http.get(this.swap_url+'people')
.map((res:Response)=>res.json())
.catch(this.handleError);
}

getPersonById(id:number)
{
return this.http.get(this.swap_url+'people/'+id)
.map((res:Response)=>res.json())
.catch(this.handleError);

}

QueryStringExample(id:number)
{
return this.http.get(this.base_url+'comments',{params:{postId:id}})
.map((res:Response)=>res.json())
.catch(this.handleError);
}

getCountries()
{
console.log("getCountries called");
console.log(countries);
var lst=[];
for(var i=0;i<countries.length;i++)
{
lst.push(countries[i]);
}

return lst;
}
    
}