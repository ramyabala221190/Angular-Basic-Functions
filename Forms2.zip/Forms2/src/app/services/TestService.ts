import{Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import {Post} from '../components/TestForMeTemplate';
import {TestComponent} from '../components/TestForMeTemplate';


@Injectable()

export class TestService
{


url:string='https://jsonplaceholder.typicode.com/';
constructor(private http:Http){}

getPosts(id:number)
{
return this.http.get(this.url+'posts/'+id)
.map((res:Response)=>res.json());

}

getPostsandUserId(query:any)
{
return this.http.get(this.url+'posts/',{params:{userId:query}})
.map((res:Response)=>res.json());
}

getComments(id:number)
{

return this.http.get(this.url+'posts/'+id+'/comments')
.map((res:Response)=>res.json());
}

getDemo(){

return this.http.get(this.url+'posts')
.flatMap((res:Response)=>res.json())
.filter((res:Response)=>res[0].id >4)
.map((res:Response)=>res.json());
}

postDemo()
{
var content:Post[]=[{
userId:"11",
id:"11",
title:"My Post",
body:"This is my post"
}];

return this.http.post(this.url+'posts',content)
.map((res:Response)=>res.json());


}

putDemo()
{
    var editedContent:any[]=[{
body:"This is my tenth post"

    }];
return this.http.put(this.url+'posts/11',editedContent)
.map((res:Response)=>res.json());
}

deleteDemo()
{
return this.http.delete(this.url+'posts/11')
.map((res:Response)=>res.json());
}

QueryDemo()
{
  
   return this.http.get(this.url+'comments',{params:{postId:'1'}})
    .map((res:Response)=>res.json());
}

}