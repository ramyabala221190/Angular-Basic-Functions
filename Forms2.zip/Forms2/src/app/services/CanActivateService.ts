import {Injectable} from '@angular/core';
import {Router,CanActivate,ActivatedRouteSnapshot,RouterStateSnapshot} from '@angular/router';


@Injectable()

export class CanActivateService implements CanActivate
{
constructor(private router:Router){}

canActivate(next: ActivatedRouteSnapshot,state: RouterStateSnapshot)
{
    console.log(state.url);
    var url=state.url;
var status=true;

if(url !=="/link/1?para=link1" && url !=="/link/2?para=link2" && url !=="/link/3?para=link3")
{
this.router.navigate(['/errorpage']);
status=false;
}

return status;
}

}