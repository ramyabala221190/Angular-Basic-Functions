import {Injectable} from '@angular/core';
import {Router,CanDeactivate,RouterStateSnapshot} from '@angular/router';
import {DeactivateComponent} from '../components/DeactivateComponentDemo';

@Injectable()

export class CanDeactivateService implements CanDeactivate<DeactivateComponent>
{
constructor(){}

canDeactivate(comp:DeactivateComponent):boolean{
var status=true;
if(comp.myname !=="" || comp.saved==false)
{
var val=confirm("Please confirm if you wish to save the form?");
if(val==true)
    {
        console.log("Accepted the save");
        comp.saveData();
        
    }
    else
    {
        console.log("rejected the save");
    }
    
    status=false;
}

    else
    {
        //redirects to /home
        status=true;
        console.log("form is not dirty");
        
    }

return status;
}

  
}
