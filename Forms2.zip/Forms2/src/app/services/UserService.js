"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
var Rx_1 = require("rxjs/Rx");
var CountriesList_1 = require("../components/CountriesList");
var UserService = (function () {
    function UserService(http) {
        this.http = http;
        this.base_url = 'https://jsonplaceholder.typicode.com/';
        this.swap_url = 'https://swapi.co/api/';
    }
    UserService.prototype.handleError = function (error) {
        console.log(error);
        return Rx_1.Observable.throw(error.json().error || 'Server error');
    };
    UserService.prototype.createComment = function (postid, ids, names, emails, comm) {
        var content = [
            {
                postId: postid,
                id: ids,
                name: names,
                email: emails,
                body: comm
            }
        ];
        return this.http.post(this.base_url + 'comments', content)
            .map(function (success) { return success.status; })
            .catch(this.handleError);
    };
    UserService.prototype.deleteComment = function (id) {
        console.log(id);
        return this.http.delete(this.base_url + 'comments/' + id)
            .map(function (success) { return success.status; })
            .catch(this.handleError);
    };
    UserService.prototype.editComment = function (postid, names, emails, comm) {
        console.log(postid);
        var editedContent = [
            /**Its of type any[] becuase we can use Comment only if we are using all its properties */
            {
                name: names,
                email: emails,
                body: comm
            }
        ];
        return this.http.put(this.base_url + 'comments/' + postid, editedContent)
            .map(function (success) { return success.status; })
            .catch(this.handleError);
    };
    /*getUserDetails()
    {
    
    
    }*/
    UserService.prototype.getAllPersonsDetails = function () {
        return this.http.get(this.swap_url + 'people')
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    UserService.prototype.getPersonById = function (id) {
        return this.http.get(this.swap_url + 'people/' + id)
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    UserService.prototype.QueryStringExample = function (id) {
        return this.http.get(this.base_url + 'comments', { params: { postId: id } })
            .map(function (res) { return res.json(); })
            .catch(this.handleError);
    };
    UserService.prototype.getCountries = function () {
        console.log("getCountries called");
        console.log(CountriesList_1.countries);
        var lst = [];
        for (var i = 0; i < CountriesList_1.countries.length; i++) {
            lst.push(CountriesList_1.countries[i]);
        }
        return lst;
    };
    return UserService;
}());
UserService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=UserService.js.map