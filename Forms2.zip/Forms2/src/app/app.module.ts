
//modules imported needs to be imported here to add it in the imports array at the bottom
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import {HttpModule} from '@angular/http';

//Component classes needs to be imported here to add it in the declarations array at the bottom
import {UserService} from './services/UserService';
import {AppComponent} from './components/AppComponent';
import {FormComponent} from './components/FormComponent';
import {LoginComponent} from './components/LoginComponent';
import {ImageComponent} from './components/ImageSelection';
import {ContactDetails} from './components/ContactDetails';
import {ErrorPageComponent} from './components/ErrorPage';
import {CanActivateService} from './services/CanActivateService';
import {DeactivateComponent} from './components/DeactivateComponentDemo';
import {CanDeactivateService} from './services/CanDeactivate';
import {IndexComponent} from './components/IndexComponent';
import {ChildComponent} from './components/ChildComponent';
import {ParentComponent} from './components/ParentComponent';
import {TestComponent} from './components/TestForMeTemplate';
import{TestService} from './services/TestService';
import {ParamTest} from './components/ParamTestComponent';
import {PostComponent} from './components/PostTemplate';
import {CommentComponent} from './components/CommentComponent';
import {UserPostComponent} from './components/UserPostComponent';
import {GeneralPostComponent} from './components/GeneralPostComponent';

const routes:Routes=[
  {
path:'',
redirectTo:'/home',
pathMatch:'full'
  },
{
path:'register',
component:FormComponent
},
{
  path:'login',
  component:LoginComponent
},
{
path:'link/:id',
component:ImageComponent,
canActivate:[CanActivateService]
},
{
  path:'getcontactdetails',
  component:ContactDetails
},
{
path:'home',
component:AppComponent
},
{
  path:'errorpage',
  component:ErrorPageComponent
},
{
  path:'deactivate',
  component:DeactivateComponent,
  canDeactivate:[CanDeactivateService]
},
{
  path:'CompRelation',
  component:ParentComponent
},
{
  path:'mytest',
  component:TestComponent
},
{
  path:'paramtest/:id',
  component:ParamTest
},
{
  path:'posts',
  component:GeneralPostComponent,
  children:[
    
    {path:':id',
    component:PostComponent,
    children:[
      {path:'comments',component:CommentComponent}
    ]
  
}
    ]
}

]

//Defines the metadata for the AppModule which is the root module of the app.
@NgModule({
  imports:      [BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes)],
  declarations: [AppComponent,ErrorPageComponent,DeactivateComponent,PostComponent,CommentComponent,UserPostComponent,
  IndexComponent,FormComponent,LoginComponent,ImageComponent,ContactDetails,ChildComponent,
  ParentComponent,TestComponent,ParamTest,GeneralPostComponent],
  bootstrap:    [IndexComponent],
  providers: [UserService,CanActivateService,CanDeactivateService,TestService] 
})

export class AppModule { }
