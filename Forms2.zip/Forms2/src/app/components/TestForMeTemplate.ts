import {Component} from '@angular/core';
import {TestService} from '../services/TestService';
import {Observable} from 'rxjs/Rx';
import {Router} from '@angular/router';

declare var $:any;



export class Post
{
   userId:string;
   id:string;
   title:string;
   body:string 
}

@Component({
templateUrl:'app/templates/TestTemplate.html'
})

export class TestComponent
{
    myname:string="";
    mypin:string="";
    myemail:string="";
    mymobile:string="";
    choices:string="";
    preference1:boolean=false;
    preference2:boolean=false;

    validate:boolean=false;

postList:any[]=[];
constructor(private serv:TestService,private router:Router){}

getName()
{
    return this.myname;
}

submitForm(testform:any)
{
    console.log("form submitted");
console.log(testform.form.controls.myname._value);
console.log(testform.form.controls.choices._value);

$('input[type=checkbox]').each(function()
{
    if($(this).is(':checked'))
    {
        console.log($(this).val());
    }
})

}

getDemo()
{
this.serv.getDemo().subscribe(
    data=>
{
    console.log(data);
  this.postList.push(data);
  this.router.navigate(['/paramtest/5'],{queryParams:{name:'yourname'}});
},
error=>
{
console.log(error);
},

()=>
{
console.log("done");
}
);
}

postDemo()
{
    this.serv.postDemo().subscribe(
        dataposted=>
    {
        console.log(dataposted);
    },
    err=>
    {
        console.log(err);
    },
    ()=>
    {
        console.log("data posted");
    }
    )
}

deleteDemo()
{
    this.serv.deleteDemo().subscribe(
        dataposted=>
    {
        console.log(dataposted);
    },
    err=>
    {
        console.log(err);
    },
    ()=>
    {
        console.log("data deleted");
    })
}

putDemo()
{
this.serv.putDemo().subscribe(dataposted=>
    {
        console.log(dataposted); //displays the edited data if successfull
    },
    err=>
    {
        console.log("error"+err.status); //displays the status code
    },
    ()=>
    {
        console.log("data edited"); //will be executed only if err is not executed
    })

}

QueryDemo()
{

    this.serv.QueryDemo().subscribe(function(data)
    {
        console.log(data);
    })
}

ValidationCheck()
{
this.validate=true;
}

ngOnInit()
{
$('input[type=checkbox]').on('change',function()
{
    console.log(this.preference1);
    console.log(this.preference2);
if($('input[name=preference1]').is(':checked') ||$('input[name=preference2]').is(':checked'))
{
$('span#errormessage').text("");
}
else
{
$('span#errormessage').text("Preferences mandatory");    
}   
})

}
}