import {Component} from '@angular/core';
import {UserService} from '../services/UserService';


declare var $:any;

@Component({

templateUrl:'app/templates/FormComponent.html',
styleUrls:['app/css/styles.css']

})

export class FormComponent
{
//ngModels are defined here
myname:string="";
mymobile:string="";
myemail:string="";
gender:string="";
teadrink:boolean=false;
coffedrinks:boolean=false;
chocodrinks:boolean=false;
sample:string;
myedu:string="";

countylist:any[]=[];
newcountylist:any[]=[];
checkboxstatus:boolean=true;

constructor(private user:UserService){}

//implementing search filter
filter()
{
    while(this.newcountylist.length >0)
{
  this.newcountylist.splice(l); 
  l++; 
}
console.log("Input changed");
var text=this.sample.toLowerCase();
var l=0;
for(var i=0;i<this.countylist.length;i++)
{
var result=this.countylist[i].toLowerCase();
console.log(result);
console.log(result.includes(text));
if(result.includes(text))
{
console.log("result"+"  "+result);
this.newcountylist.push(result);
}
}
}

register(myform:any)
{
    console.log(myform.form.controls.myedu._value);
    console.log(myform.form.controls.myname._value);
    console.log(myform.form.controls.mymobile._value);
    console.log(myform.form.controls.myemail._value);
    console.log(myform.form.controls.gender._value);
    console.log(myform.form.controls.drinks._value);

    $('input[type=checkbox]').each(function()
    {
if($(this).is(':checked'))
{
console.log($(this).val());
}
    })


}

ngOnInit()
{
console.log("form component loaded");

this.countylist=(this.user.getCountries());


//checkbox validation
$('input[type=checkbox]').change(function()
{

if($('input#tea').is(':checked') || $('input#coffee').is(':checked') || $('input#hotchoco').is(':checked'))
{


$('p#errmsg').text(""); 

}
else
{
   
  $('p#errmsg').text("Choose your preferences");  

  
}


})

}

ngOnDestroy()
{
    console.log("Form component destroyed");
}

}

