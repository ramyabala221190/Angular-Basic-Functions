import {Component} from '@angular/core';
import {ActivatedRoute,ParamMap,Router} from '@angular/router';

declare var $:any;

@Component({
templateUrl:'app/templates/ContactDetails.html' ,
styleUrls:['app/css/styles.css']   
})

export class ContactDetails
{

constructor(private route:ActivatedRoute,private router:Router){}

Gosomewhere()
{ 
this.router.navigate(['/register']);
}


ngOnInit()
{
    console.log("Contact details component loaded");

var id=this.route.snapshot.queryParams['imgid'];

    document.getElementById('modal').style.display="block";

$('span.close').on('click',function()
{
document.getElementById('modal').style.display="none";
})

$('div#cont').text(id+"  "+"details");

}

ngOnDestroy()
{
console.log("Contact details component destroyed");
}

}