"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var UserService_1 = require("../services/UserService");
var Comment = (function () {
    function Comment() {
    }
    return Comment;
}());
exports.Comment = Comment;
var AppComponent = (function () {
    function AppComponent(user_serv) {
        this.user_serv = user_serv;
        //Instance variables
        this.users = [];
        this.persons = [];
        this.createflag = false;
        this.editflag = false;
    }
    //Functions
    AppComponent.prototype.enableComment = function () {
        this.createflag = true;
    };
    AppComponent.prototype.enableEditComment = function () {
        this.editflag = true;
    };
    AppComponent.prototype.submitComment = function (postid, ids, names, emails, comm) {
        console.log(postid);
        console.log(ids);
        console.log(names);
        console.log(emails);
        console.log(comm);
        this.user_serv.createComment(postid, ids, names, emails, comm)
            .subscribe(function (data) {
            console.log(data);
        });
    };
    AppComponent.prototype.deleteComment = function (e) {
        var x = e.target;
        this.user_serv.deleteComment(x.value)
            .subscribe(function (data) {
            console.log(data);
        });
    };
    AppComponent.prototype.EditComment = function (postid, names, emails, comm) {
        this.user_serv.editComment(postid, names, emails, comm)
            .subscribe(function (data) {
            console.log(data);
        });
    };
    /*getUserDetails()
    {
    console.log("getUserDetails in component called");
    var user:any[]=[];
    
    
    this.user_serv.getUserDetails()
    .subscribe(function(data){
    
    console.log(data.profile);
    user.push(data.profile)
    
    });
    
    this.users=user;
    
    }*/
    AppComponent.prototype.getAllPersonsDetails = function () {
        this.user_serv.getAllPersonsDetails()
            .subscribe(function (data) {
            console.log(data);
        });
    };
    AppComponent.prototype.QueryStringExample = function (id) {
        this.user_serv.QueryStringExample(id).subscribe(function (data) {
            console.log(data);
        });
    };
    AppComponent.prototype.getPersonById = function (e) {
        var person = [];
        var x = e.target;
        console.log(x.value);
        this.user_serv.getPersonById(x.value)
            .subscribe(function (data) {
            console.log(data);
            person.push(data);
        });
        this.persons = person;
    };
    AppComponent.prototype.ngOnInit = function () {
        console.log("Component loading");
    };
    AppComponent.prototype.ngOnDestroy = function () {
        console.log("Component destroyed");
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: 'app/templates/appComponent.html'
    }),
    __metadata("design:paramtypes", [UserService_1.UserService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=appComponent.js.map