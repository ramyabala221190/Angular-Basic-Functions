import {Component} from '@angular/core';



@Component({
template:`<router-outlet></router-outlet>`
})

export class GeneralPostComponent
{

constructor(){}

ngOnInit()
{
console.log("General Post template loaded");
}

}