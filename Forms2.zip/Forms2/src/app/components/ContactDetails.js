"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var ContactDetails = (function () {
    function ContactDetails(route, router) {
        this.route = route;
        this.router = router;
    }
    ContactDetails.prototype.Gosomewhere = function () {
        this.router.navigate(['/register']);
    };
    ContactDetails.prototype.ngOnInit = function () {
        console.log("Contact details component loaded");
        var id = this.route.snapshot.queryParams['imgid'];
        document.getElementById('modal').style.display = "block";
        $('span.close').on('click', function () {
            document.getElementById('modal').style.display = "none";
        });
        $('div#cont').text(id + "  " + "details");
    };
    ContactDetails.prototype.ngOnDestroy = function () {
        console.log("Contact details component destroyed");
    };
    return ContactDetails;
}());
ContactDetails = __decorate([
    core_1.Component({
        templateUrl: 'app/templates/ContactDetails.html',
        styleUrls: ['app/css/styles.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router])
], ContactDetails);
exports.ContactDetails = ContactDetails;
//# sourceMappingURL=ContactDetails.js.map