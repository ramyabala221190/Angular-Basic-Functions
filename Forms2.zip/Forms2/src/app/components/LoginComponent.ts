import {Component} from '@angular/core';



@Component({

templateUrl:'app/templates/LoginComponent.html',
})

export class LoginComponent
{
constructor(){}

select:string="";
images:string[]=["Food","LifeStyle","Fashion"];
selectflag:boolean=false;

selectItem()
{
if(this.select=="")
{
this.selectflag=true;
console.log("No image selected");
}
else{
    this.selectflag=false;
    console.log(this.select);
}

}

ngOnInit()
{
    console.log("Login component loaded");
}

ngOnDestroy()
{

console.log("Login component destroyed");

}

}