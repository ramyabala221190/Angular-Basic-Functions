import {Component} from '@angular/core';
import {ActivatedRoute,ParamMap} from '@angular/router';
import {Location} from '@angular/common';


@Component({
templateUrl:'app/templates/ImageSelect.html',
styleUrls:['app/css/styles.css']
})

export class ImageComponent
{
var:string="";
message:string="";
constructor(private activeroute:ActivatedRoute,
private location:Location){}

ngOnInit()
{
    console.log("Image component loaded");


this.var=this.activeroute.snapshot.queryParams['para'];
console.log(this.var);
if(this.var=='link1')
{
this.message="You have clicked on link1";
}
if(this.var=='link2')
{
this.message="You have clicked on link2";
}
if(this.var=='link3')
{
this.message="You have clicked on link3";
}
}

goBack()
{

this.location.back();
}

ngOnDestroy()
{
console.log("Image component destroyed");

}

}