"use strict";
exports.countries = [
    'India', 'Pakistan', 'China', 'Afghanisthan'
];
//# sourceMappingURL=CountriesList.js.map