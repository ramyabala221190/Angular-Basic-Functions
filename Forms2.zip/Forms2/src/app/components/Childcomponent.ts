import {Component,Output,Input,EventEmitter} from '@angular/core';

@Component({
selector:'child',
templateUrl:'app/templates/ChildComponent.html'    
})

export class ChildComponent
{
constructor(){} 
@Input() message:any=""; //obtaining value for this from the Parent Component

@Output() clickdata:any= new EventEmitter();

handleClick()
{
this.clickdata.emit('Hello Parent');
}

}