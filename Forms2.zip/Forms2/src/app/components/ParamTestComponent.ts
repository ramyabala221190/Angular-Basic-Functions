import {Component} from '@angular/core';
import {Router,ActivatedRoute,ParamMap} from '@angular/router';

@Component({
templateUrl:'app/templates/ParamTest.html'    
})

export class ParamTest{
url:string="";
query:string="";
constructor(private route:ActivatedRoute){}

ngOnInit()
{
this.url=this.route.snapshot.params['id'];
this.query=this.route.snapshot.queryParams['name'];

}

}