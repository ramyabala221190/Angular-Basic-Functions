
export var countries:any[]=[
'India','Pakistan','China','Afghanisthan'   
];