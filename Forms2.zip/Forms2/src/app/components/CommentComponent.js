"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var TestService_1 = require("../services/TestService");
var CommentComponent = (function () {
    function CommentComponent(route, router, test) {
        this.route = route;
        this.router = router;
        this.test = test;
        this.comments = [];
    }
    CommentComponent.prototype.ngOnInit = function () {
        var _this = this;
        var id = this.route.parent.snapshot.params['id'];
        var comment = [];
        this.test.getComments(id).subscribe(function (data) {
            console.log(data);
            comment.push(data);
            console.log(comment);
        }, function (error) {
        }, function () {
            console.log("comments received for");
            _this.comments = comment;
            console.log(_this.comments);
        });
    };
    return CommentComponent;
}());
CommentComponent = __decorate([
    core_1.Component({
        templateUrl: 'app/templates/Comments.html'
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router,
        TestService_1.TestService])
], CommentComponent);
exports.CommentComponent = CommentComponent;
//# sourceMappingURL=CommentComponent.js.map