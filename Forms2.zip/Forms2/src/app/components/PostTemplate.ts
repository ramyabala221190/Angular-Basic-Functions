import {Component} from '@angular/core';
import {ActivatedRoute,Router,ParamMap} from '@angular/router';
import {TestService} from '../services/TestService';


@Component({
templateUrl:'app/templates/postTemplate.html'
})

export class PostComponent
{
myposts:any[];
constructor(private route:ActivatedRoute,private router:Router,private test:TestService){}

ngOnInit()
{
var post:any[]=[];
var query=this.route.snapshot.queryParams['userId'];
var id=this.route.snapshot.params['id'];

if(query !==undefined)
{
console.log(query);
this.test.getPostsandUserId(query).subscribe(
data=>{
console.log(data);
post.push(data);
console.log(post);
},
error=>{

},
()=>{
    console.log("Post received for");
    this.myposts=post;
console.log("final array");
console.log(this.myposts);

}

);
}
else
{
this.test.getPosts(id).subscribe(
data=>{
console.log(data);
post.push(data);
console.log(post);
},
error=>{

},
()=>{
    console.log("Post received for");
    this.myposts=post;
console.log("final array");
console.log(this.myposts);

}

);
}

}

}