"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var TestService_1 = require("../services/TestService");
var router_1 = require("@angular/router");
var Post = (function () {
    function Post() {
    }
    return Post;
}());
exports.Post = Post;
var TestComponent = (function () {
    function TestComponent(serv, router) {
        this.serv = serv;
        this.router = router;
        this.myname = "";
        this.mypin = "";
        this.myemail = "";
        this.mymobile = "";
        this.choices = "";
        this.preference1 = false;
        this.preference2 = false;
        this.validate = false;
        this.postList = [];
    }
    TestComponent.prototype.getName = function () {
        return this.myname;
    };
    TestComponent.prototype.submitForm = function (testform) {
        console.log("form submitted");
        console.log(testform.form.controls.myname._value);
        console.log(testform.form.controls.choices._value);
        $('input[type=checkbox]').each(function () {
            if ($(this).is(':checked')) {
                console.log($(this).val());
            }
        });
    };
    TestComponent.prototype.getDemo = function () {
        var _this = this;
        this.serv.getDemo().subscribe(function (data) {
            console.log(data);
            _this.postList.push(data);
            _this.router.navigate(['/paramtest/5'], { queryParams: { name: 'yourname' } });
        }, function (error) {
            console.log(error);
        }, function () {
            console.log("done");
        });
    };
    TestComponent.prototype.postDemo = function () {
        this.serv.postDemo().subscribe(function (dataposted) {
            console.log(dataposted);
        }, function (err) {
            console.log(err);
        }, function () {
            console.log("data posted");
        });
    };
    TestComponent.prototype.deleteDemo = function () {
        this.serv.deleteDemo().subscribe(function (dataposted) {
            console.log(dataposted);
        }, function (err) {
            console.log(err);
        }, function () {
            console.log("data deleted");
        });
    };
    TestComponent.prototype.putDemo = function () {
        this.serv.putDemo().subscribe(function (dataposted) {
            console.log(dataposted); //displays the edited data if successfull
        }, function (err) {
            console.log("error" + err.status); //displays the status code
        }, function () {
            console.log("data edited"); //will be executed only if err is not executed
        });
    };
    TestComponent.prototype.QueryDemo = function () {
        this.serv.QueryDemo().subscribe(function (data) {
            console.log(data);
        });
    };
    TestComponent.prototype.ValidationCheck = function () {
        this.validate = true;
    };
    TestComponent.prototype.ngOnInit = function () {
        $('input[type=checkbox]').on('change', function () {
            console.log(this.preference1);
            console.log(this.preference2);
            if ($('input[name=preference1]').is(':checked') || $('input[name=preference2]').is(':checked')) {
                $('span#errormessage').text("");
            }
            else {
                $('span#errormessage').text("Preferences mandatory");
            }
        });
    };
    return TestComponent;
}());
TestComponent = __decorate([
    core_1.Component({
        templateUrl: 'app/templates/TestTemplate.html'
    }),
    __metadata("design:paramtypes", [TestService_1.TestService, router_1.Router])
], TestComponent);
exports.TestComponent = TestComponent;
//# sourceMappingURL=TestForMeTemplate.js.map