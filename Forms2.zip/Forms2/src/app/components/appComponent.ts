import {Component} from '@angular/core';
import {UserService} from '../services/UserService';
import {Observable} from 'rxjs/Rx';


declare var $:any;

export class Comment
{
postId:number;
id:number;
name:string;
email:string;
body:string;
}

@Component(
{
selector:'my-app',
templateUrl:'app/templates/appComponent.html'
})
export class AppComponent
{
constructor(private user_serv:UserService){}

//Instance variables
users:any[]=[];
persons:any[]=[];
createflag:boolean=false;
editflag:boolean=false;

//Functions
enableComment()
{
this.createflag=true;

}

enableEditComment()
{
this.editflag=true;

}

submitComment(postid:number,ids:number,names:string,emails:string,comm:string)
{
console.log(postid);
console.log(ids);
console.log(names);
console.log(emails);
console.log(comm);

this.user_serv.createComment(postid,ids,names,emails,comm)
.subscribe(function(data)
{
console.log(data);

})

}

deleteComment(e:any)
{
var x=e.target;
this.user_serv.deleteComment(x.value)
.subscribe(function(data)
{
console.log(data);

})
}

EditComment(postid:number,names:string,emails:string,comm:string)
{
this.user_serv.editComment(postid,names,emails,comm)
.subscribe(function(data)
{
console.log(data);

})
}

/*getUserDetails()
{
console.log("getUserDetails in component called");
var user:any[]=[];


this.user_serv.getUserDetails()
.subscribe(function(data){

console.log(data.profile);
user.push(data.profile)

});

this.users=user;

}*/

getAllPersonsDetails()
{
this.user_serv.getAllPersonsDetails()
.subscribe(function(data)
{

console.log(data);
})
    
}

QueryStringExample(id:number)
{
this.user_serv.QueryStringExample(id).subscribe(function(data)
{
    console.log(data);
})

}

getPersonById(e:any)
{
var person:any[]=[];
var x=e.target;
console.log(x.value);    
this.user_serv.getPersonById(x.value)
.subscribe(function(data)
{
console.log(data);
person.push(data);   
})

this.persons=person;
}

ngOnInit()
{
console.log("Component loading"); 
   
}

ngOnDestroy()
{
console.log("Component destroyed");     
}

}

