import {Component} from '@angular/core';

@Component({
selector:'parent',
templateUrl:'app/templates/ParentComponent.html'
})

export class ParentComponent
{
constructor(){}

content:string="Hello World";

received:string="";

handleeventclicked(data:any)
{
    this.received="Message from child:"+"  "+data;
}
}