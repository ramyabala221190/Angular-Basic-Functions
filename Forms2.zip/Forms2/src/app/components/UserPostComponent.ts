import {Component} from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';

@Component({
template:'<div>UserPostComment</div>'
})

export class UserPostComponent
{
constructor(private route:ActivatedRoute,private router:Router){}

}