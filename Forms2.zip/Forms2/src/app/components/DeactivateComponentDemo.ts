import {Component} from '@angular/core';
import {Router} from '@angular/router';


declare var $:any;

@Component({
templateUrl:'app/templates/Deactivate.html'
})

export class DeactivateComponent
{
constructor(private router:Router){}
myname:string="";
saved:boolean=false;

ngOnInit()
{
    $('input').on('change',function()
    {
        console.log("input changed");
        this.saved=false;
    })
}

saveData()
{
    console.log("call saveData function");
var myarr=[];
myarr.push(this.myname);
this.saved=true;
console.log(myarr);
$('div#mess').text("Your data has been saved");
}

}