import {Component} from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {TestService} from '../services/TestService';

@Component({
templateUrl:'app/templates/Comments.html'
})

export class CommentComponent
{
    
constructor(private route:ActivatedRoute,private router:Router,
private test:TestService){}

comments:any[]=[];

ngOnInit()
{
var id=this.route.parent.snapshot.params['id'];
var comment:any[]=[];
this.test.getComments(id).subscribe(
    data=>{
console.log(data);
comment.push(data);
console.log(comment);
},
error=>{

},
()=>{
    console.log("comments received for");
    this.comments=comment;
    console.log(this.comments);
}
)


}


}