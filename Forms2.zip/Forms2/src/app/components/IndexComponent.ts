import {Component} from '@angular/core';

@Component({
selector:'index-page',
templateUrl:'app/templates/IndexComponent.html'

})

export class IndexComponent
{
    today_date:Date;
    constructor(){}

ngOnInit()
{
    this.today_date=new Date();

}
    
}