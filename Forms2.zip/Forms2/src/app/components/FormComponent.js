"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var UserService_1 = require("../services/UserService");
var FormComponent = (function () {
    function FormComponent(user) {
        this.user = user;
        //ngModels are defined here
        this.myname = "";
        this.mymobile = "";
        this.myemail = "";
        this.gender = "";
        this.teadrink = false;
        this.coffedrinks = false;
        this.chocodrinks = false;
        this.myedu = "";
        this.countylist = [];
        this.newcountylist = [];
        this.checkboxstatus = true;
    }
    //implementing search filter
    FormComponent.prototype.filter = function () {
        while (this.newcountylist.length > 0) {
            this.newcountylist.splice(l);
            l++;
        }
        console.log("Input changed");
        var text = this.sample.toLowerCase();
        var l = 0;
        for (var i = 0; i < this.countylist.length; i++) {
            var result = this.countylist[i].toLowerCase();
            console.log(result);
            console.log(result.includes(text));
            if (result.includes(text)) {
                console.log("result" + "  " + result);
                this.newcountylist.push(result);
            }
        }
    };
    FormComponent.prototype.register = function (myform) {
        console.log(myform.form.controls.myedu._value);
        console.log(myform.form.controls.myname._value);
        console.log(myform.form.controls.mymobile._value);
        console.log(myform.form.controls.myemail._value);
        console.log(myform.form.controls.gender._value);
        console.log(myform.form.controls.drinks._value);
        $('input[type=checkbox]').each(function () {
            if ($(this).is(':checked')) {
                console.log($(this).val());
            }
        });
    };
    FormComponent.prototype.ngOnInit = function () {
        console.log("form component loaded");
        this.countylist = (this.user.getCountries());
        //checkbox validation
        $('input[type=checkbox]').change(function () {
            if ($('input#tea').is(':checked') || $('input#coffee').is(':checked') || $('input#hotchoco').is(':checked')) {
                $('p#errmsg').text("");
            }
            else {
                $('p#errmsg').text("Choose your preferences");
            }
        });
    };
    FormComponent.prototype.ngOnDestroy = function () {
        console.log("Form component destroyed");
    };
    return FormComponent;
}());
FormComponent = __decorate([
    core_1.Component({
        templateUrl: 'app/templates/FormComponent.html',
        styleUrls: ['app/css/styles.css']
    }),
    __metadata("design:paramtypes", [UserService_1.UserService])
], FormComponent);
exports.FormComponent = FormComponent;
//# sourceMappingURL=FormComponent.js.map