import {Component} from '@angular/core';

@Component({
templateUrl:'app/templates/errorpage.html'
})

export class ErrorPageComponent
{

}