"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
//modules imported needs to be imported here to add it in the imports array at the bottom
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
//Component classes needs to be imported here to add it in the declarations array at the bottom
var UserService_1 = require("./services/UserService");
var AppComponent_1 = require("./components/AppComponent");
var FormComponent_1 = require("./components/FormComponent");
var LoginComponent_1 = require("./components/LoginComponent");
var ImageSelection_1 = require("./components/ImageSelection");
var ContactDetails_1 = require("./components/ContactDetails");
var ErrorPage_1 = require("./components/ErrorPage");
var CanActivateService_1 = require("./services/CanActivateService");
var DeactivateComponentDemo_1 = require("./components/DeactivateComponentDemo");
var CanDeactivate_1 = require("./services/CanDeactivate");
var IndexComponent_1 = require("./components/IndexComponent");
var ChildComponent_1 = require("./components/ChildComponent");
var ParentComponent_1 = require("./components/ParentComponent");
var TestForMeTemplate_1 = require("./components/TestForMeTemplate");
var TestService_1 = require("./services/TestService");
var ParamTestComponent_1 = require("./components/ParamTestComponent");
var PostTemplate_1 = require("./components/PostTemplate");
var CommentComponent_1 = require("./components/CommentComponent");
var UserPostComponent_1 = require("./components/UserPostComponent");
var GeneralPostComponent_1 = require("./components/GeneralPostComponent");
var routes = [
    {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full'
    },
    {
        path: 'register',
        component: FormComponent_1.FormComponent
    },
    {
        path: 'login',
        component: LoginComponent_1.LoginComponent
    },
    {
        path: 'link/:id',
        component: ImageSelection_1.ImageComponent,
        canActivate: [CanActivateService_1.CanActivateService]
    },
    {
        path: 'getcontactdetails',
        component: ContactDetails_1.ContactDetails
    },
    {
        path: 'home',
        component: AppComponent_1.AppComponent
    },
    {
        path: 'errorpage',
        component: ErrorPage_1.ErrorPageComponent
    },
    {
        path: 'deactivate',
        component: DeactivateComponentDemo_1.DeactivateComponent,
        canDeactivate: [CanDeactivate_1.CanDeactivateService]
    },
    {
        path: 'CompRelation',
        component: ParentComponent_1.ParentComponent
    },
    {
        path: 'mytest',
        component: TestForMeTemplate_1.TestComponent
    },
    {
        path: 'paramtest/:id',
        component: ParamTestComponent_1.ParamTest
    },
    {
        path: 'posts',
        component: GeneralPostComponent_1.GeneralPostComponent,
        children: [
            { path: ':id',
                component: PostTemplate_1.PostComponent,
                children: [
                    { path: 'comments', component: CommentComponent_1.CommentComponent }
                ]
            }
        ]
    }
];
//Defines the metadata for the AppModule which is the root module of the app.
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, router_1.RouterModule.forRoot(routes)],
        declarations: [AppComponent_1.AppComponent, ErrorPage_1.ErrorPageComponent, DeactivateComponentDemo_1.DeactivateComponent, PostTemplate_1.PostComponent, CommentComponent_1.CommentComponent, UserPostComponent_1.UserPostComponent,
            IndexComponent_1.IndexComponent, FormComponent_1.FormComponent, LoginComponent_1.LoginComponent, ImageSelection_1.ImageComponent, ContactDetails_1.ContactDetails, ChildComponent_1.ChildComponent,
            ParentComponent_1.ParentComponent, TestForMeTemplate_1.TestComponent, ParamTestComponent_1.ParamTest, GeneralPostComponent_1.GeneralPostComponent],
        bootstrap: [IndexComponent_1.IndexComponent],
        providers: [UserService_1.UserService, CanActivateService_1.CanActivateService, CanDeactivate_1.CanDeactivateService, TestService_1.TestService]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map