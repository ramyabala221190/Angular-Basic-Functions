"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var heroDetail_service_1 = require("./heroDetail.service");
var Hero = (function () {
    function Hero() {
    }
    return Hero;
}());
exports.Hero = Hero;
var AppComponent = (function () {
    function AppComponent(heroService) {
        this.heroService = heroService;
        this.cnt = 0;
        this.herolist = [];
    }
    /*selectedhero:SelectedHeros[]=[];
    
    details:Details[]=[];
    
    View(ind:number)
    {
    this.details.push(this.selectedhero[ind]);
    console.log(this.details);
    }
    
    remove(ind:number)
    {
    this.selectedhero.splice(ind,1);
    //this.cnt=this.cnt-1;
    }
    
    selected(ref:number)
    {
    this.cnt=this.cnt+1;
    var refer=ref+1;
    $('table').find('tr:eq('+ refer +')').css('color','blue');
    this.selectedhero.push(this.herolist[ref]);
    }*/
    AppComponent.prototype.editHero = function (ind) {
        var name = window.prompt("Enter a new name");
        console.log(name);
        if (name !== null) {
            /*for(var i=0;i<this.selectedhero.length;i++)
            {
            
              if(this.herolist[ind].name==this.selectedhero[i].name)
              {
            this.selectedhero[i].name=name;
            break;
              }
            } */
            this.herolist[ind].name = name;
        }
    };
    AppComponent.prototype.removeHero = function (ind) {
        var conf = window.confirm("Are you sure you want to remove this superhero?");
        if (conf) {
            /*for(var i=0;i<this.selectedhero.length;i++)
            {
            
              if(this.herolist[ind].name==this.selectedhero[i].name)
              {
            this.selectedhero.splice(i,1);
            this.cnt=this.cnt-1;
            break;
              }
            } */
            this.herolist.splice(ind, 1);
        }
    };
    AppComponent.prototype.ngOnInit = function () {
        this.herolist = this.heroService.getHero();
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: 'app/templates/HeroComponent.html',
        styleUrls: ['app/css/styles.css']
    }),
    __metadata("design:paramtypes", [heroDetail_service_1.HeroService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map