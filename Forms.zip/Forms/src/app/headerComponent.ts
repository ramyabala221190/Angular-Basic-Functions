import {Component} from '@angular/core';

@Component(
{
selector:'header-Comp',
templateUrl:'app/templates/headerComponent.html',
styleUrls:['app/css/styles.css']
})

export class HeaderComponent
{
title:string='Tour of heroes';
}