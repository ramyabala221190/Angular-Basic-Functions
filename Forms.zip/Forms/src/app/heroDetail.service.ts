import {Injectable} from '@angular/core';

import {Hero} from './app.component';
import {heroism} from './mockHeroes';

@Injectable()

export class HeroService
{
TopHeroes:Hero[]=[];

getHero():Hero[]{

return heroism;

}

getHeroById(id:number)
{
  for(var i=0;i<heroism.length;i++)
  {
      if(heroism[i].id==id)
      {
          return heroism[i];
      }
  }
}

getFewHeroes(count:number)
{
for(var i=0;i<count;i++)
{

this.TopHeroes.push(heroism[i]);

}

return this.TopHeroes;

}

}