import {Component} from '@angular/core';

import {Hero} from './app.component';
import {HeroService} from './heroDetail.service';

import {ActivatedRoute} from '@angular/router';
import { Location }                 from '@angular/common';


@Component(
{
selector:'detail-comp',
templateUrl:'app/templates/DetailsComponent.html'
})


export class DetailsComponent
{
heroes={};
details:Hero[]=[];
private selectedId: number=0;

constructor(
  private heroService: HeroService,
  private route: ActivatedRoute,//We are injecting the actiated route here
  private location: Location
) {}

goBack()
{
  this.location.back();
}


ngOnInit() {
var serv=this.heroService;
var det:Hero[]=[];
//We are doing the above assignments because we cannot use this inside the function
//.function(params) is used instead of params=>
//In the latter, this keyword can be used but in case of function we cannot.
  this.heroes = this.route.params.subscribe(function(params) {

    console.log(params['id']);
    this.selectedId = params['id'];
   det.push(serv.getHeroById(this.selectedId));
      });
      this.details=det;
}
}

