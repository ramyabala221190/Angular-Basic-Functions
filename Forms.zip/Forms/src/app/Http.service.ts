import {Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()

export class HttpService
{

constructor(private http:Http){}

getUser()
{
console.log("Get user called");
return this.http
/**.get('https://conduit.productionready.io/api/profiles/eric')*/
.get('https://swapi.co/api/people')
.map((res:Response)=>res.json())

}

}