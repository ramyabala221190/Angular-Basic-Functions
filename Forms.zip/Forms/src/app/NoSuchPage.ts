import {Component} from '@angular/core';

@Component({
selector:'no-page',
templateUrl:'app/templates/NoSuchPageComponent.html'

})

export class NoSuchPage
{


}