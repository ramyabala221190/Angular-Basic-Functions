"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var heroDetail_service_1 = require("./heroDetail.service");
var Http_service_1 = require("./Http.service");
var DashBoard = (function () {
    function DashBoard(heroservice, httpservice) {
        this.heroservice = heroservice;
        this.httpservice = httpservice;
        this.myheroes = [];
        //profile:profiles[];
        this.profile = [];
    }
    DashBoard.prototype.LoadUser = function () {
        console.log("load user called");
        //var pro:profiles[]=[];
        var pro = [];
        this.httpservice.getUser().subscribe(function (data) {
            console.log(data.results);
            pro.push(data.results);
        });
        this.profile = pro;
        console.log(this.profile);
    };
    DashBoard.prototype.ngOnInit = function () {
        this.myheroes = this.heroservice.getFewHeroes(5);
    };
    return DashBoard;
}());
DashBoard = __decorate([
    core_1.Component({
        selector: 'dash-board',
        templateUrl: 'app/templates/DashBoardComponent.html'
    }),
    __metadata("design:paramtypes", [heroDetail_service_1.HeroService,
        Http_service_1.HttpService])
], DashBoard);
exports.DashBoard = DashBoard;
/**export class profiles
{
username:string="";
bio:string="";
image:string="";
following:string="";
}*/
var StarWars = (function () {
    function StarWars() {
    }
    return StarWars;
}());
exports.StarWars = StarWars;
//# sourceMappingURL=DashBoard.component.js.map