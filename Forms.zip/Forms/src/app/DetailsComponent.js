"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var heroDetail_service_1 = require("./heroDetail.service");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var DetailsComponent = (function () {
    function DetailsComponent(heroService, route, //We are injecting the actiated route here
        location) {
        this.heroService = heroService;
        this.route = route;
        this.location = location;
        this.heroes = {};
        this.details = [];
        this.selectedId = 0;
    }
    DetailsComponent.prototype.goBack = function () {
        this.location.back();
    };
    DetailsComponent.prototype.ngOnInit = function () {
        var serv = this.heroService;
        var det = [];
        //We are doing the above assignments because we cannot use this inside the function
        //.function(params) is used instead of params=>
        //In the latter, this keyword can be used but in case of function we cannot.
        this.heroes = this.route.params.subscribe(function (params) {
            console.log(params['id']);
            this.selectedId = params['id'];
            det.push(serv.getHeroById(this.selectedId));
        });
        this.details = det;
    };
    return DetailsComponent;
}());
DetailsComponent = __decorate([
    core_1.Component({
        selector: 'detail-comp',
        templateUrl: 'app/templates/DetailsComponent.html'
    }),
    __metadata("design:paramtypes", [heroDetail_service_1.HeroService,
        router_1.ActivatedRoute,
        common_1.Location])
], DetailsComponent);
exports.DetailsComponent = DetailsComponent;
//# sourceMappingURL=DetailsComponent.js.map