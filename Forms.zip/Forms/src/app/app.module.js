"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
//modules imported needs to be imported here to add it in the imports array at the bottom
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
//Component classes needs to be imported here to add it in the declarations array at the bottom
var app_component_1 = require("./app.component");
var headerComponent_1 = require("./headerComponent");
var DetailsComponent_1 = require("./DetailsComponent");
var heroDetail_service_1 = require("./heroDetail.service");
var NoSuchPage_1 = require("./NoSuchPage");
var DashBoard_component_1 = require("./DashBoard.component");
var Http_service_1 = require("./Http.service");
//Defining an array of objects of type Routes. This will be added as arg to forRoot()
var routes = [
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'heroes',
        component: app_component_1.AppComponent
    },
    {
        path: 'dashboard',
        component: DashBoard_component_1.DashBoard
    },
    {
        path: 'detail/:id',
        component: DetailsComponent_1.DetailsComponent
    },
    {
        path: '**',
        component: NoSuchPage_1.NoSuchPage
    }
];
/**The ** path in the last route is a wildcard.
 *  The router will select this route if the requested URL doesn't match
 * any paths for routes defined earlier in the configuration.
 * This is useful for displaying a "404 - Not Found" page or
 * redirecting to another route. */
//Defines the metadata for the AppModule which is the root module of the app.
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule.forRoot(routes), http_1.HttpModule],
        declarations: [app_component_1.AppComponent, headerComponent_1.HeaderComponent, DetailsComponent_1.DetailsComponent, NoSuchPage_1.NoSuchPage, DashBoard_component_1.DashBoard],
        bootstrap: [headerComponent_1.HeaderComponent],
        providers: [heroDetail_service_1.HeroService, Http_service_1.HttpService]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map