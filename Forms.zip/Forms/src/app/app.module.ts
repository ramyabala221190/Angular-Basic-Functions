
//modules imported needs to be imported here to add it in the imports array at the bottom
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import {HttpModule} from '@angular/http';

//Component classes needs to be imported here to add it in the declarations array at the bottom
import { AppComponent }  from './app.component';
import {HeaderComponent} from './headerComponent';
import {DetailsComponent} from './DetailsComponent';
import {HeroService} from './heroDetail.service';
import {NoSuchPage} from './NoSuchPage';
import {DashBoard} from './DashBoard.component';
import {HttpService} from './Http.service';


//Defining an array of objects of type Routes. This will be added as arg to forRoot()
const routes:Routes=[
{
  path: '',
  redirectTo: '/dashboard',
  pathMatch: 'full'
},

{
path:'heroes',
component:AppComponent
  },
  {
path:'dashboard',
component:DashBoard

  },
{
path:'detail/:id',
component:DetailsComponent
},
{
path:'**',
component:NoSuchPage
}
];

/**The ** path in the last route is a wildcard.
 *  The router will select this route if the requested URL doesn't match 
 * any paths for routes defined earlier in the configuration. 
 * This is useful for displaying a "404 - Not Found" page or 
 * redirecting to another route. */

//Defines the metadata for the AppModule which is the root module of the app.
@NgModule({
  imports:      [ BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpModule],
  declarations: [ AppComponent,HeaderComponent,DetailsComponent,NoSuchPage,DashBoard],
  bootstrap:    [ HeaderComponent],
  providers: [HeroService,HttpService] 
})



export class AppModule { }
