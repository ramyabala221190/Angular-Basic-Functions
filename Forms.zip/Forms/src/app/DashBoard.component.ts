import {Component} from '@angular/core';

import {HeroService} from './heroDetail.service';

import {Hero} from './app.component';

import {HttpService} from './Http.service';

@Component({
selector:'dash-board',
templateUrl:'app/templates/DashBoardComponent.html'

})

export class DashBoard
{

constructor(
    private heroservice:HeroService,
    private httpservice:HttpService){}
 myheroes:Hero[]=[];

 //profile:profiles[];
 profile:StarWars[]=[];

 LoadUser()
 {
console.log("load user called");
//var pro:profiles[]=[];
var pro:StarWars[]=[];
this.httpservice.getUser().subscribe(function(data:any)
{
console.log(data.results);
pro.push(data.results);

})
this.profile=pro;
console.log(this.profile);
 }


 ngOnInit(): void{

this.myheroes=this.heroservice.getFewHeroes(5);


 }

}

/**export class profiles
{
username:string="";
bio:string="";
image:string="";
following:string="";
}*/

export class StarWars
{
birth_year:string;
eye_color:string;
films:string[];
gender:string;
hair_color:string;
height:string;
homeworld:string;
mass:string;
name:string;
skin_color:string;
species:string[];
starships:string[];
vehicles:string[];
}
