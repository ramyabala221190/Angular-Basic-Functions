import { Component } from '@angular/core';
import {HeroService} from './heroDetail.service';
declare var $: any;

export class Hero{

name:string;
id:number;
description:string;

}


@Component({
  selector: 'my-app',
  templateUrl: 'app/templates/HeroComponent.html',
  styleUrls:['app/css/styles.css']
})
export class AppComponent  { 

cnt:number=0;

herolist: Hero[] = [];

/*selectedhero:SelectedHeros[]=[];

details:Details[]=[];

View(ind:number)
{
this.details.push(this.selectedhero[ind]);
console.log(this.details);
}

remove(ind:number)
{
this.selectedhero.splice(ind,1);
//this.cnt=this.cnt-1;
}

selected(ref:number)
{
this.cnt=this.cnt+1;
var refer=ref+1;
$('table').find('tr:eq('+ refer +')').css('color','blue');
this.selectedhero.push(this.herolist[ref]);
}*/

editHero(ind:number)
{
var name=window.prompt("Enter a new name");
console.log(name);
if(name !==null)
{
/*for(var i=0;i<this.selectedhero.length;i++)
{

  if(this.herolist[ind].name==this.selectedhero[i].name)
  {
this.selectedhero[i].name=name;
break;
  }
} */
this.herolist[ind].name=name;
}
}

removeHero(ind:number)
{
var conf=window.confirm("Are you sure you want to remove this superhero?");

if(conf)
{

/*for(var i=0;i<this.selectedhero.length;i++)
{

  if(this.herolist[ind].name==this.selectedhero[i].name)
  {
this.selectedhero.splice(i,1);
this.cnt=this.cnt-1;
break;
  }
} */
this.herolist.splice(ind,1); 

}

}

constructor(private heroService: HeroService) { }

ngOnInit()
{
  this.herolist=this.heroService.getHero();
}

}

